import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
//This the index page that renders the App to the html page
ReactDOM.render(<App />, document.getElementById("root"));
