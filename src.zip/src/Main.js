import React from "react";
import Me from "./media/me.jpg";

// this is the Man component, iit out lines the contents of the card in JSX

function Main() {
  return (
    <main className="mainClass">
      <h1 className="headerText">Daniil Pleskach</h1>
      <div className="businessCard">
        <img src={Me} alt="me" className="bcImageClass" />
        <p>#4706 Terwillegar Common NW</p>
        <p>T6R 3H5</p>

        <p>Edmonton</p>

        <p>Alberta</p>

        <p>Canada</p>

        <p>
          <strong>Tel</strong>: (587) 432-1541
        </p>

        <p>
          <strong>email</strong>:
          <a href="mailto:daple1997@gmail.com">daple1997@gmail.com</a>
        </p>

        <p>
          <strong>LinkedIn</strong>:
          <a href="https://www.linkedin.com/in/daniil-pleskach-53621815a/">
            https://www.linkedin.com/in/daniil-pleskach-53621815a/
          </a>
        </p>

        <p>
          <strong>Github Profile</strong>:
          <a href="https://github.com/daple1997">
            https://github.com/daple1997
          </a>
        </p>
      </div>
    </main>
  );
}
export default Main;
